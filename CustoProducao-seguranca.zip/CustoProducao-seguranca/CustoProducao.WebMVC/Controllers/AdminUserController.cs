﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CustoProducao.Infrastructure.Identity;
using CustoProducao.Core.Interfaces;
using CustoProducao.WebMVC.Extentions;

namespace CustoProducao.WebMVC.Controllers
{
    [Authorize]
    [Route("[controller]/[action]")]
    public class AdminUserController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IdentityUserRole<int> _identityUserRole;
        private readonly SignInManager<IdentityUser> _signInManager;
        private readonly IEmailSender _emailSender;
        private readonly ILogger _logger;
        private readonly AppIdentityDbContext _context;

        public AdminUserController(
            UserManager<IdentityUser> userManager,
            IdentityUserRole<int> identityUserRole,
            SignInManager<IdentityUser> signInManager,
            IEmailSender emailSender,
            ILogger<AccountController> logger,
            AppIdentityDbContext context)
        {
            _userManager = userManager;
            _identityUserRole = identityUserRole;
            _signInManager = signInManager;
            _emailSender = emailSender;
            _logger = logger;
            _context = context;
        }

        
        public ActionResult Index()
        {
            return View(_context.Users.ToList());
        }

        public ActionResult Delete(string id)
        {
            var user = _context.Users.Where(u => u.Id == id).FirstOrDefault();
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(IdentityUser appuser)
        {
            var user = _context.Users.Where(u => u.Id == appuser.Id).FirstOrDefault();
            _context.Users.Remove(user);
            _context.SaveChanges();
            //var user = context.Users.Where(u => u.Id == id.ToString()).FirstOrDefault();
            return RedirectToAction("Index");
        }

        public ActionResult Edit(string id)
        {
            var user = _context.Users.Where(u => u.Id == id).FirstOrDefault();
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(IdentityUser appuser)
        {
            var user = _context.Users.Where(u => u.Id == appuser.Id).FirstOrDefault();
            //context.Entry(appuser).State = EntityState.Modified;
            user.UserName = appuser.UserName;
            user.Email = appuser.Email;
            user.PhoneNumber = appuser.PhoneNumber;
            _context.SaveChanges();
            //var user = context.Users.Where(u => u.Id == id.ToString()).FirstOrDefault();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UserName,Email,PhoneNumber")] IdentityUser appuser)
        {
            if (ModelState.IsValid)
            {
                var user = new IdentityUser { UserName = appuser.UserName, Email = appuser.Email, PhoneNumber = appuser.PhoneNumber };
                var result = await _userManager.CreateAsync(user, "@CustoProd01" );
                if (result.Succeeded)
                {
                    _logger.LogInformation("User created a new account with password.");

                    var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                    var callbackUrl = Url.EmailConfirmationLink(user.Id, code, Request.Scheme);
                    await _emailSender.SendEmailConfirmationAsync(appuser.Email, callbackUrl);

                    await _signInManager.SignInAsync(user, isPersistent: false);
                    _logger.LogInformation("User created a new account with password.");
                    return RedirectToLocal(nameof(Index));
                }
                AddErrors(result);
            }

            // If we got this far, something failed, redisplay form
            return View(appuser);
        }

        #region Helpers

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }

        private IActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction(nameof(HomeController.Index), "Home");
            }
        }

        #endregion
    }
}
