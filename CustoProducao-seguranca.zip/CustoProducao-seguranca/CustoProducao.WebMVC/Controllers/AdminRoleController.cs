﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CustoProducao.Infrastructure.Identity;
using CustoProducao.Core.Interfaces;

namespace CustoProducao.WebMVC.Controllers
{
    [Authorize]
    [Route("[controller]/[action]")]
    public class AdminRoleController : Controller
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IEmailSender _emailSender;
        private readonly ILogger _logger;
        private readonly AppIdentityDbContext _context;

        public AdminRoleController(
            RoleManager<IdentityRole> roleManager,
            IEmailSender emailSender,
            ILogger<AdminRoleController> logger,
            AppIdentityDbContext context)
        {
            _roleManager = roleManager;
            _emailSender = emailSender;
            _logger = logger;
            _context = context;
        }

        
        public ActionResult Index()
        {
            return View(_context.Roles.ToList());
        }

        //public async Task<IActionResult> Index()
        //{
        //    return View(await _context.Roles.ToAsyncEnumerable<IdentityRole>());
        //}

        public ActionResult Delete(string id)
        {
            var role = _context.Roles.Where(r => r.Id == id).FirstOrDefault();
            return View(role);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(IdentityRole approle)
        {
            var role = _context.Roles.Where(r => r.Id == approle.Id).FirstOrDefault();
            _context.Roles.Remove(role);
            _context.SaveChanges();
            //var user = context.Users.Where(u => u.Id == id.ToString()).FirstOrDefault();
            return RedirectToAction("Index");
        }

        public ActionResult Edit(string id)
        {
            var role = _context.Roles.Where(r => r.Id == id).FirstOrDefault();
            return View(role);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(IdentityRole approle)
        {
            var role = _context.Roles.Where(r => r.Id == approle.Id).FirstOrDefault();
            role.Name = approle.Name;
            role.NormalizedName = approle.Name;
            _context.SaveChanges();
            return RedirectToAction("Index");
        }


        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Name")] IdentityRole appRole)
        {
            if (ModelState.IsValid)
            {
                var role = new IdentityRole { Name = appRole.Name};
                var result = await _roleManager.CreateAsync(role);
                if (result.Succeeded)
                {
                    _logger.LogInformation("Role created.");
                    return RedirectToLocal(nameof(Index));
                }
                AddErrors(result);
            }

            // If we got this far, something failed, redisplay form
            return View(appRole);
        }

        #region Helpers

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }

        private IActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction(nameof(HomeController.Index), "Home");
            }
        }

        #endregion
    }
}
