﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using CustoProducao.Core.Interfaces;
using CustoProducao.Infrastructure.Data;
using CustoProducao.Infrastructure.Identity;
using CustoProducao.Infrastructure.Services;
using CustoProducao.Infrastructure.Logging;
using AutoMapper;
using CustoProducao.Core.Manager.Contracts;
using CustoProducao.Core.Manager.Implementation;
using CustoProducao.Core.Translation;
using CustoProducao.WebMVC.Translator;

namespace CustoProducao
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<CustoProducaoDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DBCustoProducaoContext")));

            services.AddDbContext<AppIdentityDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("IdentityConnection")));

            services.AddIdentity<ApplicationUser, IdentityRole>()
                .AddEntityFrameworkStores<AppIdentityDbContext>()
                .AddDefaultTokenProviders();

            // Add application services.
            services.AddScoped(typeof(IAppLogger<>), typeof(LoggerAdapter<>));
            services.AddScoped<IEmpresaManager, EmpresaManager>();
            services.AddScoped<IEmpresaRepository, EmpresaRepository>();
            services.AddSingleton<IEntityTranslator, AutoMapperTranslator>();

            services.AddAutoMapper();

            services.AddTransient<IEmailSender, EmailSender>();


            services.AddMvc()
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
