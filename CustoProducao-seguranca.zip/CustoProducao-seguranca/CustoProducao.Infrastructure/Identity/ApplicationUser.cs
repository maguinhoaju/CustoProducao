﻿using Microsoft.AspNetCore.Identity;

namespace CustoProducao.Infrastructure.Identity
{
    public class ApplicationUser : IdentityUser
    {
    }
}
