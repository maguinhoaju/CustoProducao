﻿
namespace CustoProducao.Core.Translation
{
    public interface ITranslatorFactory
    {
        /// <summary>
        /// Cria o mapeador automático de propriedades de objetos.
        /// </summary>
        /// <returns></returns>
        IEntityTranslator Create();
    }
}
