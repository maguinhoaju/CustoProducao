﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustoProducao.Core.Translation
{
    /// <summary>
    /// Fabrica de mapeador de propriedades de objetos
    /// </summary>
    public static class TranslatorFactory
    {
        #region Members

        static ITranslatorFactory _factory = null;

        #endregion

        #region Public Methods

        /// <summary>
        /// Set the mapper factory to use
        /// </summary>
        /// <param name="factory">Map factory to use</param>
        public static void SetCurrent(ITranslatorFactory factory)
        {
            _factory = factory;
        }

        /// <summary>
        /// Create a new Mapper
        /// </summary>
        /// <returns>Created IMapper</returns>
        public static IEntityTranslator CreateMapper()
        {
            return (_factory != null) ? _factory.Create() : null;
        }

        #endregion
    }
}
