﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustoProducao.Core.Translation
{
    /// <summary>
    /// Entity Translator Pattern base contract.
    /// </summary>
    public interface IEntityTranslator
    {
        /// <summary>
        /// Valida se o tipo pode ser mapeado para o destino especificado.
        /// </summary>
        /// <typeparam name="TSource">Tipo do objeto de origem</typeparam>
        /// <typeparam name="TTarget">Tipo do objeto de destino</typeparam>
        /// <returns></returns>
        bool CanTranslate<TSource, TTarget>();

        /// <summary>
        /// Mapeia o objeto passado para o tipo especificado.
        /// </summary>
        /// <typeparam name="TTarget">Tipo do objeto de destino</typeparam>
        /// <param name="source">Objeto de origem</param>
        /// <returns></returns>
        TTarget Translate<TTarget>(object source);

        /// <summary>
        /// Mapeia o <see cref="IQueryable"/> pra o tipo especificado de objeto.
        /// </summary>
        /// <typeparam name="TSource">Tipo do objeto no repositório a ser consultado</typeparam>
        /// <typeparam name="TTarget">Tipo do objeto de destino do resultado da consulta</typeparam>
        /// <param name="source"></param>
        /// <returns></returns>
        IQueryable<TTarget> Translate<TSource, TTarget>(IQueryable<TSource> source);
    }
}
