﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CustoProducao.Core.Util
{
    public interface IUtilities
    {
        ILogger Logger { get; set; }
    }
}
