﻿using System;
using System.Linq;
using System.IO;
using Microsoft.Extensions.Logging;

namespace CustoProducao.Core.Util
{
    /// <summary>
    /// Utilitários do sistema
    /// </summary>
    public class Utilities : IUtilities
    {
        public Utilities(ILogger logger)
        {
            Logger = logger;
        }

        public ILogger Logger { get; set; }
    }
}
