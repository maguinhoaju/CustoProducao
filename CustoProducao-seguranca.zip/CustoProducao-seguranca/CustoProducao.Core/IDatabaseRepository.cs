﻿using CustoProducao.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace CustoProducao.Core
{
    /// <summary>
    /// Base interface to implement Repository Pattern
    /// </remarks>
    /// <typeparam name="T">Type of entity for this repository </typeparam>
    public interface IDatabaseRepository<T> : IRepository<T>, IDisposable
        where T : class
    {
        /// <summary>
        /// Obter a unidade de trabalho neste repositório
        /// </summary>
        IUnitOfWork UnitOfWork { get; }

        /// <summary>
        /// Acompanha a entidade para este repositório, em UnitOfWork.
        /// No EF isso pode ser feito anexando e atualizando o NH
        /// </summary>
        /// <param name="item">Item a ser anexado</param>
        void TrackItem(T item);

        /// <summary>
        /// Define a entidade como modificada no repositório.
        /// Ao chamar Commit () em UnitOfWork
        /// essas alterações serão salvas no armazenamento
        /// </summary>
        /// <param name="persistido">O item persistido</param>
        /// <param name="atual">O item atual</param>
        void Merge(T persistido, T atual);

        /// <summary>
        /// Obter todos os elementos do tipo T no repositório
        /// </summary>
        /// <returns>Lista de elementos selecionados</returns>
        IEnumerable<T> GetAll();

        /// <summary>
        /// Obter os elementos do tipo T no repositório de acordo com o filtro
        /// </summary>
        /// <returns>Lista de elementos selecionados</returns>
        IEnumerable<T> GetFiltered(Expression<Func<T, bool>> filter);

        /// <summary>
        /// Obter os elementos do tipo T no repositório de acordo com o filtro
        /// </summary>
        /// <returns>Lista de elementos selecionados</returns>
        IEnumerable<T> GetFiltered<Property>(Expression<Func<T, bool>> filter, Expression<Func<T, Property>> orderExpression, bool ascending);

        /// <summary>
        /// Obter o número total de elementos resultante da pesqusisa de acordo com o filtro
        /// </summary>
        /// <returns>número total de elementos</returns>
        int Count(Expression<Func<T, bool>> filter);

        /// <summary>
        /// Get all elements of type T that matching a
        /// Specification <paramref name="specification"/>
        /// </summary>
        /// <param name="specification">Specification that result meet</param>
        /// <returns></returns>
        IEnumerable<T> AllMatching(ISpecification<T> specification);

        /// <summary>
        /// Get all elements of type T in repository
        /// </summary>
        /// <param name="pageNumber">Page index</param>
        /// <param name="pageSize">Number of elements in each page</param>
        /// <param name="orderByExpression">Order by expression for this query</param>
        /// <param name="ascending">Specify if order is ascending</param>
        /// <returns>List of selected elements</returns>
        IEnumerable<T> GetPaged<Property>(int pageNumber, int pageSize, Expression<Func<T, Property>> orderByExpression, bool ascending);

        /// <summary>
        /// Obtem os elementos de acordo com filtro, a ordenação e o número de pagina
        /// </summary>
        /// <param name="pageNumber">Número da página</param>
        /// <param name="pageSize">Número de elementos por página</param>
        /// <param name="orderByExpression">Expressão de ordenação</param>        
        /// <returns>Lista de elementos</returns>
        IEnumerable<T> GetPaged<Property>(int pageNumber, int pageSize, Expression<Func<T, bool>> expression, Expression<Func<T, Property>> orderExpression);

        /// <summary>
        /// Expõe consultas mais elaboradas a ser executadas pelo ORM ou pela implementação equivalente.
        /// </summary>
        /// <returns></returns>
        IQueryable<T> Query();
    }
}
