﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CustoProducao.Core.Entities
{
    [Table("TB_EMPRESA")]
    public class Empresa : BaseEntity
    {
        [Key]
        [Column("ID_EMPRESA", Order = 0, TypeName = "INT")]
        public int IdEmpresa { get; set; }

        [Column("NR_CNPJ", Order = 1)]
        public long NrCnpj { get; set; }

        [Column("NM_EMPRESA", Order = 2)]
        public string NmEmpresa { get; set; }

        public ICollection<Insumo> Insumos { get; set; }
    }
}
