﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CustoProducao.Core.Entities
{
    [Table("TB_INSUMO")]
    public partial class Insumo : BaseEntity
    {
        [Key]
        [Column("ID_INSUMO", Order = 0, TypeName = "INT")]
        public int IdInsumo { get; set; }

        [Column("CD_INSUMO", Order = 2, TypeName = "VARCHAR(30)")]
        public string CdInsumo { get; set; }

        [Column("DT_INSUMO_CADASTRO", Order = 3)]
        public DateTime DtInsumoCadastro { get; set; }

        [Column("NM_INSUMO", Order = 4)]
        public string NmInsumo { get; set; }

        [Column("DS_INSUMO", Order = 5)]
        public string DsInsumo { get; set; }

        [Column("VL_INSUMO_NOTA", Order = 6, TypeName = "DECIMAL (18, 2)")]
        public decimal VlInsumoNota { get; set; }

        [Column("VL_INSUMO_FRETE", Order = 7, TypeName = "DECIMAL (18, 2)")]
        public decimal VlInsumoFrete { get; set; }

        [ForeignKey("TB_EMPRESA")]
        [Column("ID_EMPRESA", Order = 1)]
        public int IdEmpresa { get; set; }

//        [ForeignKey("ID_EMPRESA")]
        public Empresa Empresa { get; set; }
    }
}
