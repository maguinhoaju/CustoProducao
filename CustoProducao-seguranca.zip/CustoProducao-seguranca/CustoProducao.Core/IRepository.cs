﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustoProducao.Core
{
    public interface IRepository<T> where T : class
    {
        /// <summary>
        /// Obter elemento pela chave da entidade
        /// </summary>
        /// <param name="id">Valor da chave da entidade</param>
        /// <returns></returns>
        T Get(object id);

        /// <summary>
        /// Adicionar item no repositório
        /// </summary>
        /// <param name="item">Item para adicionar ao repositório</param>
        void Add(T item);

        /// <summary>
        /// Deletar item do repositório
        /// </summary>
        /// <param name="item">Item a ser deletado</param>
        void Remove(T item);

        /// <summary>
        /// Definir item para ser modificado no repositório
        /// </summary>
        /// <param name="item">Item a ser modificado</param>
        void Update(T item);
    }
}
