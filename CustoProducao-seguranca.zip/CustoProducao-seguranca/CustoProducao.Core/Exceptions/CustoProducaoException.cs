﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustoProducao.Core.Exceptions
{
    public class CustoProducaoException : Exception
    {
        public CustoProducaoException(string message) : base(message)
        {
        }
    }
}
