﻿using CustoProducao.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CustoProducao.Core.Manager.Contracts
{
    public interface IInsumoManager
    {
        IEnumerable<Insumo> ListAll(int idEmpresa);
    }
}
