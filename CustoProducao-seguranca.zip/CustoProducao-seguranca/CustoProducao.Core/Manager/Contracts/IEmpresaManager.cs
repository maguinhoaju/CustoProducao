﻿using CustoProducao.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CustoProducao.Core.Manager.Contracts
{
    public interface IEmpresaManager
    {
        Task<Empresa> GetByIdAsync(int id);
        Task<List<Empresa>> ListAllAsync();
        Task<Empresa> AddAsync(Empresa entity);
        Task UpdateAsync(Empresa entity);
        Task DeleteAsync(Empresa entity);

    }
}
