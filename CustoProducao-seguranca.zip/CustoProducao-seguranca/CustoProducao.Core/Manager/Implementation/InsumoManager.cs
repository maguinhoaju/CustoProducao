﻿using CustoProducao.Core.Entities;
using CustoProducao.Core.Manager.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using CustoProducao.Core.Interfaces;

namespace CustoProducao.Core.Manager.Implementation
{
    public class InsumoManager : BaseManager, IInsumoManager
    {
        private readonly IInsumoRepository _insumoRepository;
        private readonly IAppLogger<Insumo> _logger;


        public InsumoManager(IInsumoRepository insumoRepository, IAppLogger<Insumo> logger)
        {
            this._insumoRepository = insumoRepository;
            _logger = logger;
        }

        public void Add(Insumo item)
        {
            _logger.LogDebug($"Classe: '{this.GetType().ToString()}' Metodo: Add", item);
            _insumoRepository.Add(item);
        }

        public Insumo GetById(int id)
        {
            return _insumoRepository.GetById(id);
        }

        public IEnumerable<Insumo> ListAll(int idEmpresa)
        {
            return _insumoRepository.ListAll(idEmpresa);
        }

        public void Delete(Insumo item)
        {
            _insumoRepository.Delete(item);
        }

        public void Update(Insumo item)
        {
            _insumoRepository.Update(item);
        }
    }
}
