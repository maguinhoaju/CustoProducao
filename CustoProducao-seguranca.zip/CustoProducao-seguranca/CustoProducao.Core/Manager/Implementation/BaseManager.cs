﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;
using CustoProducao.Core.Manager.Contracts;

namespace CustoProducao.Core.Manager.Implementation
{
    public abstract class BaseManager
    {
    }
}
