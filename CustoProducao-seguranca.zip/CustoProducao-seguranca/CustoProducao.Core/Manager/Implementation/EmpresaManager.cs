﻿using CustoProducao.Core.Entities;
using CustoProducao.Core.Interfaces;
using CustoProducao.Core.Helpers;
using CustoProducao.Core.Manager.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using CustoProducao.Core.Exceptions;
using System.Threading.Tasks;

namespace CustoProducao.Core.Manager.Implementation
{
    public class EmpresaManager : BaseManager, IEmpresaManager
    {
        private readonly IEmpresaRepository _empresaRepository;
        private readonly IAppLogger<Empresa> _logger;

        public EmpresaManager(IEmpresaRepository empresaRepository, IAppLogger<Empresa> logger)
        {
            this._empresaRepository = empresaRepository;
            this._logger = logger;
        }

        public void Add(Empresa item)
        {
            _logger.LogDebug($"Classe: '{this.GetType().ToString()}' Metodo: Add", item);
            if (CNPJHelper.IsCnpj(item.NrCnpj.ToString()))
            {
                _empresaRepository.Add(item);
            }
            else
            {
                throw new CustoProducaoException($"O CNPJ '{item.NrCnpj}' não é válido.");
            }
        }

        public Empresa GetById(int id)
        {
            return _empresaRepository.GetById(id);
        }

        public void Delete(Empresa item)
        {
            _empresaRepository.Delete(item);
        }

        public void Update(Empresa item)
        {
            _empresaRepository.Update(item);
        }

        public async Task<List<Empresa>> ListAllAsync()
        {
            return await _empresaRepository.ListAllAsync();
        }

        public async Task<Empresa> GetByIdAsync(int id)
        {
            return await _empresaRepository.GetByIdAsync(id);
        }

        public async Task<Empresa> AddAsync(Empresa entity)
        {
            return await _empresaRepository.AddAsync(entity);
        }

        public async Task UpdateAsync(Empresa entity)
        {
            await _empresaRepository.UpdateAsync(entity);
        }

        public async Task DeleteAsync(Empresa entity)
        {
            await _empresaRepository.DeleteAsync(entity);
        }
    }
}
