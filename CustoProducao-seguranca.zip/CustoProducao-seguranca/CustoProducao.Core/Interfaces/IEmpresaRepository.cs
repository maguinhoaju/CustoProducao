﻿using CustoProducao.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CustoProducao.Core.Interfaces
{
    public interface IEmpresaRepository : IRepository<Empresa>, IAsyncRepository<Empresa>
    {
    }
}
