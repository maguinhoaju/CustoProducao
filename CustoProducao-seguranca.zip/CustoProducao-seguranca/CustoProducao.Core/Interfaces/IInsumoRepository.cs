﻿using CustoProducao.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace CustoProducao.Core.Interfaces
{
    public interface IInsumoRepository : IRepository<Insumo>
    {
        IEnumerable<Insumo> ListAll(int idEmpresa);
    }
}
